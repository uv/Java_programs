//2.	Write a C program to enter two numbers and perform all arithmetic operations.
#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
	
	printf("\n Enter the value of a\n");
	scanf("%d",&a);
	
	printf("\n Enter the value of b\n");
	scanf("%d",&b);
	
	c=a+b;
	printf("\n Result of Addition is %d\n",c);
	
	c=a-b;
	printf("\n Result of Subtraction is %d\n",c);
	
	c=a*b;
	printf("\n Result of Multiplication is %d\n",c);
	
	c=a/b;
	printf("\n Result of Division is %d\n",c);
	
	getch();
}
