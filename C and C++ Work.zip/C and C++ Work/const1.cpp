#include<iostream>
using namespace std;
class stud
{
	public:
	int rollno;
	char name[10];
	
	void accept();
	void display();
};

void stud::accept()
{
	cout<<"\n Enter a rollno of student";
	cin>>rollno;
	
	cout<<"\n Enter a name of student";
	cin>>name;
}

void stud::display()
{
	cout<<"\n Rollno of student is:"<<rollno;
	cout<<"\n Name of student is:"<<name;
}

int main()
{
	stud s;
	s.accept();
	s.display();
	return(0);
}
