#include<stdio.h>
#include<conio.h>

int main()
{
	int i=5;
	printf("%d",printf("%d",printf("%d",printf("%d",i))));
	return 0;
}
