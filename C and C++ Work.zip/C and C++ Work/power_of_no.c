//10.	Write a C program to find power of any number x ^ y.
#include<stdio.h>
#include<conio.h>

void main()
{
	int square,no;
	
	printf("\n Enter a Number\n");
	scanf("%d",&no);
	
	square=no*no;
	printf("\n Power of no is%d\n",square);
	
	getch();
	
}
