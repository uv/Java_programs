#include<conio.h>
#include<stdio.h>
 void main()
 {
 	int i;
 	for(i=0;i<10;i++)
 	{
 		if(i/2==0)
 		{
 			goto out;
		 }
		 out:
		 	printf("\n Evenn Number %d",i);
	 }
 }
