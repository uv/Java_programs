//6.	Write a C program to enter length in centimeter and convert it into meter and kilometer.
#include<stdio.h>
#include<conio.h>
void main()
{
	float centimeter,meter,kilometer;
	
	printf("\n Enter the value of Centimeter\n");
	scanf("%f",&centimeter);
	printf("\n Centimeter is%f\n",centimeter);
	
	meter=centimeter/100;
	printf("\n Meter is%f\n",meter);
	
	kilometer=centimeter/100000;
	printf("\n Kilometer is%f\n",kilometer);
	
	getch();

}
