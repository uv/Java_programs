//13.	Write a C program to enter base and height of a triangle and find its area.
#include<stdio.h>
#include<conio.h>

void main()
{
	float base,height,area;
	
	printf("\n Enter a Base of Triangle\n");
	scanf("%f",&base);
	
	printf("\n Enter a Height of Triangle\n");
	scanf("%f",&height);
	
	area=(base*height)/2;
	printf("\n Area of Triangle is%f\n",area);
	
	getch();
	
}
