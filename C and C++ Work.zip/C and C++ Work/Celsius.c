//8.	Write a C program to enter temperature in Fahrenheit(�F) and convert it into Celsius(�C)
#include<stdio.h>
#include<conio.h>

void main()
{
	float Fahrenheit,Celsius;
	
	printf("\n Enter Temprature in Fahrenheit\n");
	scanf("%f",&Fahrenheit);
	
	Celsius=(Fahrenheit-32)*1.8;
	printf("\n Temprature in Celsius is%f\n",Celsius);
	
	getch();
}
