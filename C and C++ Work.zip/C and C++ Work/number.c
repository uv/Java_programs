#include<stdio.h>
#include<conio.h>
main()
{
	int i;
	for(i=0;i<10;i++)
	{
		printf("\n Number are=%d",i);
	}
	getch();
}
