//1.	Write a C program to enter two numbers and find their sum.
#include<stdio.h>
#include<conio.h>
void main()
{
	int a,b,c;
	
	printf("\n Enter the value of a\n");
	scanf("%d",&a);
	
	printf("\n Enter the value of b\n");
	scanf("%d",&b);
	
	c=a+b;
	printf("\n Result of addition is %d\n",c);
	
	getch();
	
}
