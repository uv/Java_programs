#include<stdio.h>
#include<conio.h>
 
int main() 
{
   char str[20],ch;
   int i,count=0;
 
   printf("\n Enter a string : ");
   scanf("%s",&str);
   
 printf("%s",str);
   printf("\n Enter the character to be searched :");
   scanf("%s",&ch);
   printf("hiii");
   for(i=0;i<10;i++) 
   {
   	printf("%d",i);
   	printf("%c",str[i]);
      if (str[i]==ch){
	  
         ++count;
         printf("%d",count);
     }
   }
   printf("%d",count);
   if(count<0)
{
	       printf("\n Character '%c'is not present",ch);
	   }
   else
      printf("\n Occurence of character '%c' : %d",ch,count);
   return (0);
}
