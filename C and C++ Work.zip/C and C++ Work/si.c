//16.	Write a C program to enter P, T, R and calculate Simple Interest.
#include<stdio.h>
#include<conio.h>
void main()
{
	float P,T,R,Simple_Interest;
	
	printf("\n Enter P, T and R\n");
	scanf("%f%f%f",&P,&T,&R);
	
     printf("\n P:%f\n T:%f\n R:%f\n",P,T,R);

    Simple_Interest=(P+T+R)/100;
    printf("\n Simple_Interest is:%f\n",Simple_Interest);
}
