#include<stdio.h>
#include<conio.h>

struct student
{
	int rollno;
	char name[5];
}str;

struct family
{
	int parent_id;
	struct student str;
}fam;

void main()
{
	printf("\n Enter RollNo of student\n");
	scanf("%d",&fam.str.rollno);
	printf("\n Enter Name of student\n");
	scanf("%s",&fam.str.name);
	printf("\n Enter Contact of Parents\n");
	scanf("%d",&fam.parent_id);
	
	printf("\n RollNo of student is:%d\n",fam.str.rollno);
	printf("\n Name of student is:%s\n",fam.str.name);
	printf("\n Contact of Parent is:%d\n",fam.parent_id);
	
}
