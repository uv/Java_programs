//9.	Write a C program to convert days into years, weeks and days.
#include<stdio.h>
#include<conio.h>

void main()
{
	int weeks,days,year;
	printf("\n Enter a Days in Year\n");
	scanf("%d",&days);
	printf("\n Days in Year %d\n",days);
	
	weeks=days/7;
	printf("\n Week in Year %d\n",weeks);
	
	year=days/days;
	printf("\n Year is%d\n",year);
}
