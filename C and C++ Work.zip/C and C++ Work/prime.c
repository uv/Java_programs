#include<conio.h>
#include<stdio.h>

void main()
{
	int no,i;
		printf("\n enter no is\n");
		scanf("%d",&no);
		if(no/2==0)
		{
			no=no%2;
			printf("\n  not prime\n");
		}
		else
		{
			printf("\n  prime");
		}
	}
