//4.	Write a C program to enter length and breadth of a rectangle and find its area.
#include<stdio.h>
#include<conio.h>
void main()
{
	float length,breadth,area;
	
	printf("\n Enter the length of rectangle\n");
	scanf("%f",&length);
	
	printf("\n Enter the breadth of rectangle\n");
	scanf("%f",&breadth);
	
	area=length*breadth;
	printf("\n Perimeter of rectangle is%f",area);
	
	getch();

}
