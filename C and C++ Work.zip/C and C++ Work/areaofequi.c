//14.	Write a C program to calculate area of an equilateral triangle.
#include<stdio.h>
#include<conio.h>

void main()
{
	float side,area;
	
	printf("\n Enter a Side of Equilateral \n");
	scanf("%f",&side);
	
	area=0.433*(side*side);
	printf("\n Area of Equilateral is%f\n",area);
	
	getch();
	
}
