#include<stdio.h>
#include<conio.h>

void main()
{
	int i,j,k,x;
	for(i=1;i<=3;i++)
	{
		for(j=3;j>i;j--)
		{
			printf(" ");
		}
		for(k=1;k<=i;k++)
		{
			printf("*");
		}
	/*	for(x=i-1;x>0;x--)
		{
		printf("*");
	    }*/
	    printf("\n");
	}
}
