//5.	Write a C program to enter radius of a circle and find its diameter, circumference and area.
#include<stdio.h>
#include<conio.h>
void main()
{
	float circum,diameter,area,radius,pi=3.14;
	
	printf("\n Enter the Radius of circle\n");
	scanf("%f",&radius);
	
	area=3.14*radius*radius;
	printf("\n Area of rectangle is%f",area);
	
	diameter=2*radius;
	printf("\n Diameter of rectangle is%f",diameter);
	
	circum=3.14*diameter;
	printf("\n circumference of rectangle is%f",circum);
	
	getch();

}
