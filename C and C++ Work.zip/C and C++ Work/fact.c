#include<stdio.h>
#include<conio.h>
long int fact(int no);
 int main()
{
	int no;
	printf("\n Enter a no\n");
	scanf("%d",&no);
	printf("\n Factorial of %d=%ld\n",no,fact(no));
	return 0;
}
long int fact(int no)
{
 if (no >= 1)
        return no*fact(no-1);
    else
        return 1;
}
