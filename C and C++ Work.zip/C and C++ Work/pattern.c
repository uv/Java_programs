#include<stdio.h>
#include<conio.h>

void main()
{
	int i,j,k;
	printf("\n Pattern is\n");
	for(i=4;i>=0;i--)
	{
			for(j=i;j<=3;j++)
			{
				printf(" ");
			}
				for(k=0;k<=i;k++)
				{
					printf("*");
					printf(" ");	
				}
				printf("\n");
			
			}
}

