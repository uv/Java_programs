#include<stdio.h>
#include<conio.h>

void main()
{
	int fno=0,sno=1,tno,pos,i=1;
	printf("\n enter a last pos");
	scanf("%d",&pos);
	printf("\n 1st no%d\n:",fno);
	printf("\n 2nd no%d\n:",sno);
	while(i<=pos)
	{
		tno=fno+sno;
		printf("\n tno= %d",tno);
		fno=sno;
		sno=tno;
		i++;
	}
}
