//12.	Write a C program to enter two angles of a triangle and find the third angle.
#include<stdio.h>
#include<conio.h>

void main()
{
	float first_angle,second_angle,third_angle;
	
	printf("\n Enter a First Angle of Triangle\n");
	scanf("%f",&first_angle);
	
	printf("\n Enter a Second Angle of Triangle\n");
	scanf("%f",&second_angle);
	
	third_angle=180-(first_angle+second_angle);
	printf("\n Third Angle of Triangle is%f\n",third_angle);
	
	getch();
	
}
