#include<conio.h>
#include<stdio.h>
 main()
{
	int i,j;
	int a[3][3];
	printf("\n enter array element");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
    	{
			scanf("%d%d",&a[i][j]);
		}
			
	}
	printf("\n Matrix is %d%d",a[i][j]);
	if(a[i][j]==a[i+1][j+1])
	{
		printf("\n Matrix is diagonal");
	}
	else
	{
		printf("\n Matrix is not diagonal");
	}
}
