#include <stdio.h>
int main()
{
   char ch;
   FILE *fp;
   if (fp = fopen("d:/test.txt", "r"))
   {
     ch = getc(fp);
      printf("\n enter a name\n");
   	scanf("%s",ch);
   	fprintf(fp,"\n Name is:%s",ch);
     while (ch != EOF)
     {   
        putc(ch,fp);
        ch = getc(fp);
     }
     fclose(fp);
     return 0;
   }
   return 1;
}
