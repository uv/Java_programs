//11.	Write a C program to enter any number and calculate its square root.
#include<stdio.h>
#include<conio.h>

void main()
{
	int no;
	float square_root;
	
	printf("\n Enter a Number\n");
	scanf("%d",&no);
	
	square_root=sqrt(no);
	printf("\n  of no is%f\n",square_root);
	
	getch();
	
}
