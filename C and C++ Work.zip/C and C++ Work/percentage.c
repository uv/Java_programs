//15.	Write a C program to enter marks of five subjects and calculate total, average and percentage.
#include<stdio.h>
#include<conio.h>
void main()
{
	int m1,m2,m3,m4,m5,i;
	float per,avg,temp;
	
	printf("\n Enter five subject marks\n");
	for(i=0;i<1;i++)
	{
		scanf("%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5);
	}
	
	for(i=0;i<1;i++)
	{
     printf("\n Subject1:%d\n Subject2:%d\n Subject3:%d\n Subject4:%d\n Subject5:%d\n",m1,m2,m3,m4,m5);
    }
    temp=m1+m2+m3+m4+m5;
    avg=temp/5;
    printf("\n Average of marks%f\n",avg);
    
    
    per=(temp*100)/500;
    printf("\n Percentage of marks%f\n",per);
}
