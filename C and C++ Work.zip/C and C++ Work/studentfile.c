#include<stdio.h>
#include<conio.h>
void main()
{
	int rollno,i;
	char name[20],ch;
	float marks;
	FILE *fp;
	 if (fp = fopen("d:/uv.txt","w"))
 		{
     		rollno=getc(fp);
     		name[i]=getc(fp);
     		marks=getc(fp);
     		ch=getc(fp);
     	}
		for(i=0;i<1;i++)
		{
			printf("\n enter the rollno of student\n");
			scanf("%d",&rollno);
			printf("\n enter the name of student\n");
			scanf("%s",&name);
			printf("\n enter the marks of student\n");
			scanf("%f",&marks);
		}
		for(i=0;i<1;i++)
		{
		fprintf(fp,"\n RollNo of student is:%d",rollno);
		fprintf(fp,"\n Name of student is:%s",name);
		fprintf(fp,"\n Marks of student is:%f",marks);
    	}
		while(ch!= EOF)	
		{	   
        		putc(rollno,fp);
        		putc(name[i],fp);
        		putc(marks,fp);
        		rollno = getc(fp);
        		name[i]= getc(fp);
        		marks= getc(fp);
     	}
     		fclose(fp);
}
