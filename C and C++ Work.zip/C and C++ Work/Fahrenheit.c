//7.	Write a C program to enter temperature in �Celsius and convert it into �Fahrenheit.
#include<stdio.h>
#include<conio.h>

void main()
{
	float Fahrenheit,Celsius;
	
	printf("\n Enter Temprature in Celsius\n");
	scanf("%f",&Celsius);
	
	Fahrenheit=(Celsius*1.8)+32;
	printf("\n Temprature in Fahrenheit is%f\n",Fahrenheit);
	
	getch();
}
