#include<iostream>
using namespace std;
int fact(int no);
int main()
{
	int no;
	cout<<"Enter Positive Integer number";
	cin>>no;
	cout<<"Factorial of no is "<< no <<"----"<< fact(no);
	return 0;
}
int fact(int no)
{
	if(no>1)
	return no*fact(no-1);
	else
	return 1;
}
