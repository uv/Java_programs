#include<stdio.h>
#include<conio.h>

void main()
{
	int i,j,k;
	printf("\n Pattern is\n");
	for(i=1;i<5;i++)
	{
			printf("\n\n");
			printf("         ");
			for(j=1;j<=i;j++)
			{
				printf("*");
				printf("%d",i);	
			
			}
}
}
